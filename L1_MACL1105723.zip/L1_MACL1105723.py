'''variable1= 5000 #
print("Comentario")
print(variable1)
print(type(variable1))

variable1="hola"
print(variable1)
print(type(variable1))

variable2=121.0
print(variable2)
print(type(variable2))

variable3= True
print(variable3)
print(type(variable3)'''
      
#print("Hola mundo soy Melvin")

'''print("Hola mundo")
print("Soy Melvin")
#cuando no tiene end continuea en la siguiente linea
e
print("Hola mundo", end="")
print("Soy Melvin", end="")
#el end hace que continue en la misma linea sin dejar espacio'''
print("Ingrese su nombre")
texto = input()
print(texto + " hola")