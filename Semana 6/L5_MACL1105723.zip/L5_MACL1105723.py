print("Ejercicio 1")
v1 = input("Ingrese un numero entero: ")
vnum = int(v1)
if vnum > 0:
    print("RESULTADO: Su numero es positivo")

elif vnum < 0:
    print("RESULTADO: Su numero es negativo")
else:
    print("RESULTADO: Su numero es 0")

