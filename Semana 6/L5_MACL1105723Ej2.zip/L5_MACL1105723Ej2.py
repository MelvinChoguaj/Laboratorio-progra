print("Ejercicio2")
x=input("Ingrese su numero de dia: ")
xnum=int(x)
if xnum <= 0 or xnum >= 8:
    print("ERROR. El numero a ingresar debe estar contenido entre el 1 y 7")
elif xnum ==1:
    print("DIA: Lunes")
elif xnum ==2:
    print("DIA: Martes")
elif xnum ==3:
    print("DIA: Miercoles")
elif xnum ==4:
    print("DIA: Jueves")
elif xnum ==5:
    print("DIA: Viernes")
elif xnum ==6:
    print("DIA: Sabado")
elif xnum ==7:
    print("DIA: Domingo")